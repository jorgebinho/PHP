<?php 

include '../adm/conecta.php';


$login = $_POST['login'];
$senha = MD5($_POST['senha']);


if(!$connect){
  
  die ('falha na conexão'.  mysqli_connect_error());
}


$query_select = "SELECT login FROM usuarios WHERE login = '$login'";
$select = mysqli_query($connect, $query_select);

if (mysqli_num_rows($select) > 0) {
   die("Usuario já existe");

}

$query = "INSERT INTO usuarios (login,senha) VALUES ('$login','$senha')";
$insert = mysqli_query($connect, $query);

if($insert){
  echo"<script language='javascript' type='text/javascript'>alert('Usuário cadastrado com sucesso!');//window.location.href='login.html'</script>";
}else{
  echo"<script language='javascript' type='text/javascript'>alert('Não foi possível cadastrar esse usuário');//window.location.href='cadastro.html'</script>";
}


?>