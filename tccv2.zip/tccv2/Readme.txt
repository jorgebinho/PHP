Thanks for downloading this theme!

Theme Name: Imperial
Theme URL: https://bootstrapmade.com/imperial-free-onepage-bootstrap-theme/
Author: BootstrapMade.com
Author URL: https://bootstrapmade.com

Aula de biologiA

Grande circulação: 
veia - venoso
artéria - arterial

Pequena circulação
entra no coração -- veia
sai do coração -- artéria

Artérias
conduzem o sangue do coração para
qualquer parte do corpo(saem do 
coração); pressão sanguínea 
elevada(alta resistência);

Capilares: constituídos por
uma única camada de células
(endotélio); trocas de 
substâncias entre o sangue
e os demais tecidos

Veias: conduzem o sangue de
qualquer parte do corpo para o
coração (chegam no coração);
pressão sanguínea baixa(menor
resistência e presença de válvulas)
para evitar o refluxo sanguíneo
