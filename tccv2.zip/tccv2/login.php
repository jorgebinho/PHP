<?php 
include 'adm/conecta.php';


  $login = $_POST['login'];
  $senha = $_POST['senha'];


  $stmt = $connect->prepare( "SELECT * FROM usuarios WHERE login = '$login' AND senha = '$senha'");
  $stmt->execute();

  if($stmt->rowCount($login, $senha) == 0){
    echo"<script language='javascript' type='text/javascript'>
   alert('Login e/ou senha incorretos');
   window.location.href='index.html';
  </script>";
  }
 else{
  setcookie("login",$login);
  header("Location:adm/index.php");
}
?>