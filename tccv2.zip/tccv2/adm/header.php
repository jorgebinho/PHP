﻿<!DOCTYPE html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Bate Bola Futebol Society</title>
    <link href="<?php echo SCRIPT_ROOT; ?>adm/css/bootstrap.min.css?id=343" rel="stylesheet" media="screen"> 
    <link href="<?php echo SCRIPT_ROOT; ?>adm/css/font-awesome.css" rel="stylesheet" media="screen"> 
</head>
<body><div class="scrollmenu">

</div>
<a class="navbar-brand" href="<?php echo SCRIPT_ROOT; ?>adm/clientes/index.php" title='Gerenciamento de Clientes'>Clientes</a>
<a class="navbar-brand" href="<?php echo SCRIPT_ROOT; ?>adm/quadra/index.php" title='Gerenciamento de Quadras'>Quadras</a>
<a class="navbar-brand" href="<?php echo SCRIPT_ROOT; ?>adm/categorias/index.php" title='Gerenciamento de Categorias'>Categorias</a>
<a class="navbar-brand" href="<?php echo SCRIPT_ROOT; ?>adm/aluno/index.php" title='Gerenciamento dos alunos'>Alunos</a>
<a class="navbar-brand" href="<?php echo SCRIPT_ROOT; ?>adm/pagamentos/index.php" title='Gerenciamento de Pagamentos'>Pagamentos</a>
<a class="navbar-brand" href="<?php echo SCRIPT_ROOT; ?>adm/turmas/index.php" title='Gerenciamento das Turmas'>Turmas</a>
<a class="navbar-brand" href="<?php echo SCRIPT_ROOT; ?>adm/agenda/index.php" title='Gerenciamento de Calendários'>Agenda</a>
<a class="navbar-brand" href="<?php echo SCRIPT_ROOT; ?>adm/sair.php" title='Logout'>Sair</a>
<a class="navbar-brand" href="<?php echo SCRIPT_ROOT; ?>adm/noticia/index.php" title="Notícia">Notícias</a>

</nav>
</ul>