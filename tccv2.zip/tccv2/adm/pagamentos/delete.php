﻿<?php
include_once '../config.php';
//ver o segurança.php 
include_once '../conecta.php';
include_once '../header.php'; 
include_once 'class.crud.php';
$crud = new crud($connect);
if(isset($_POST['btn-del']))
{
	$id = $_GET['delete_id'];
	$crud->delete($id);
	header("Location: delete.php?deleted");	
}
?>
<div class="clearfix"></div>

<div class="container">

	<?php
	if(isset($_GET['deleted']))
	{
		?>
        <div class="alert alert-success">
    	<strong>APAGOU</strong></div>
        <?php
	}
	else
	{
		?>
        <div class="alert alert-danger">
    	<strong>Aten&ccedil;&atilde;o !</strong> Quer apagar o registro ? 
		</div>
        <?php
	}
	?>	
</div>

<div class="clearfix"></div>

<div class="container">
 	
	 <?php
	 if(isset($_GET['delete_id']))
	 {
		 ?>
         <table class='table table-bordered'>
         <tr>
         <th>#</th>
         <th>Vencimento</th>
         <th>Data do pagamento</th>
         <th>Valor</th>
         <th>Descrição</th>
         </tr>
         <?php

         $stmt = $connect->prepare("SELECT * FROM pag WHERE id=:id");
         $stmt->execute(array(":id"=>$_GET['delete_id']));
         while($row=$stmt->fetch(PDO::FETCH_BOTH))
         {
             ?>
             <tr>
             <td><?php print($row['id']); ?></td>
             <td><?php print($row['vencimento']); ?></td>
             <td><?php print($row['data_pag']); ?></td>
         	 <td><?php print($row['valor']); ?></td>
             <td><?php print($row['descricao']); ?></td>
             </tr>
             <?php
         }
         ?>
         </table>
         <?php
	 }
	 ?>
</div>
<div class="container">
<p>
<?php
if(isset($_GET['delete_id']))
{
	?>
  	<form method="post">
    <input type="hidden" name="id" value="<?php echo $row['id']; ?>" />
    <button class="btn btn-large btn-primary" type="submit" name="btn-del"><i class="glyphicon glyphicon-trash"></i> &nbsp; SIM</button>
    <a href="index.php" class="btn btn-large btn-success"><i class="glyphicon glyphicon-backward"></i> &nbsp; N&Atilde;O</a>
    </form>  
	<?php
}
else
{
	?>
    <a href="index.php" class="btn btn-large btn-success"><i class="glyphicon glyphicon-backward"></i> &nbsp; Volte para In&iacute;cio</a>
    <?php
}
?>
</p>
</div>	