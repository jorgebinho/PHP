<?php
include_once '../config.php';
include_once '../conecta.php';
include_once '../header.php'; 

include_once 'class.crud.php';
$crud = new crud($connect);

if(isset($_POST['btn-update']))
{
    $id = $_GET['edit_id'];
	$vencimento = $_POST['vencimento'];
	$data_pag = $_POST['data_pag'];
    $valor = $_POST['valor'];
    $descricao = $_POST['descricao'];
    $clientes_id = $_POST['clientes_id'];
	
    if($crud->update($id,$vencimento,$data_pag,$valor,$descricao,$clientes_id))
    {
		$msg = "<div class='alert alert-info'>
				<strong>WOW!</strong> Registro gravado com sucesso <a href='index.php'>&nbsp; Volte para In&iacute;cio</a>!
				</div>";
	}
	else
	{
		$msg = "<div class='alert alert-warning'>
				<strong>SORRY!</strong> Erro ao atualizar o registro !
				</div>";
	}
}

if(isset($_GET['edit_id']))
{
	$id = $_GET['edit_id'];
    extract($crud->getID($id));	
    $pag =  $crud->getID($id);
}


?>


<div class="clearfix"></div>

<div class="container">
<?php
if(isset($msg))
{
	echo $msg;
}
?>
</div>

<div class="clearfix"></div><br />

<div class="container">
	 
     <form method='post'>
 
    <table class='table table-bordered'>
 
        <tr>
            <td>Vencimento</td>
            <td><input type='date' name='vencimento' class='form-control' value="<?php echo $vencimento; ?>" required></td>
        </tr>
 
        <tr>
            <td>Data do pagamenot</td>
            <td><input type='date' name='data_pag' class='form-control' value="<?php echo $data_pag; ?>" required></td>
        </tr>
 
        <tr>
            <td>Valor</td>
            <td><input type='int' name='valor' class='form-control' value="<?php echo $valor; ?>" required></td>
        </tr>
 
        <tr>
            <td>Descrição</td>
            <td><input type='text' name='descricao' class='form-control' value="<?php echo $descricao; ?>" required></td>
        </tr>
        <tr>
            <td>Responsável</td>
            <td>
            <?php 
                $crud->getDropDow("clientes", "nome", "clientes_id", $pag['clientes_id'])
            ?>
            </td>
        </tr>
     
        <tr>
            <td colspan="2">
                <button type="submit" class="btn btn-primary" name="btn-update">
    			<span class="glyphicon glyphicon-edit"></span>  Atualizar registro
				</button>
                <a href="index.php" class="btn btn-large btn-success"><i class="glyphicon glyphicon-backward"></i> &nbsp; CANCELAR</a>
            </td>
        </tr>
 
    </table>
</form>
     
     
</div>
