<?php
	// inicio da sessão
	session_start();
	
	function seguranca_adm(){
		if((empty($_SESSION['login'])) || (empty($_SESSION['senha']))){		
		
			$_SESSION['loginErro'] =  "<script>alert(' RESTRITO! Área somente para administradores. '); 
					 window.location.assign('index.php')</script>";
			header("Location: ../adm/index.php");
		}
		}
?>
