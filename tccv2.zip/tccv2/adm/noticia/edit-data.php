<?php
include_once '../config.php';
include_once '../conecta.php';
include_once '../header.php'; 

include_once 'class.crud.php';
$crud = new crud($connect);


if(isset($_POST['btn-update']))
{
	$id = $_GET['edit_id'];
	$texto = $_POST['texto'];
	$titulo = $_POST['titulo'];
	
	if($crud->update($id,$texto,$titulo))
	{
		$msg = "<div class='alert alert-info'>
				<strong>WOW!</strong> Registro gravado com sucesso <a href='index.php'>&nbsp; Volte para In&iacute;cio</a>!
				</div>";
	}
	else
	{
		$msg = "<div class='alert alert-warning'>
				<strong>SORRY!</strong> Erro ao atualizar o registro !
				</div>";
	}
}

if(isset($_GET['edit_id']))
{
	$id = $_GET['edit_id'];
	extract($crud->getID($id));	
}

?>


<div class="clearfix"></div>

<div class="container">
<?php
if(isset($msg))
{
	echo $msg;
}
?>
</div>

<div class="clearfix"></div><br />

<div class="container">
	 
     <form method='post'>
 
    <table class='table table-bordered'>
  <tr>
            <td>Título</td>
            <td><input type='text' name='titulo' class='form-control' value="<?php echo $titulo; ?>" required></td>
        </tr> 
       
        <tr>
            <td>Texto</td>
            <td><input type='text' name='texto' class='form-control' value="<?php echo $texto; ?>" required></td>
        </tr> 
        <tr>
            <td colspan="2">
                <button type="submit" class="btn btn-primary" name="btn-update">
    			<span class="glyphicon glyphicon-edit"></span>  Atualizar registro
				</button>
                <a href="index.php" class="btn btn-large btn-success"><i class="glyphicon glyphicon-backward"></i> &nbsp; CANCELAR</a>
            </td>
        </tr>
 
    </table>
</form>
     
     
</div>
