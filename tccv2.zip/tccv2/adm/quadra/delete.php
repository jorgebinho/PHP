﻿<?php
include_once '../config.php';
//ver o segurança.php 
include_once '../conecta.php';
include_once '../header.php'; 
include_once 'class.crud.php';
$crud = new crud($connect);
if(isset($_POST['btn-del']))
{
	$id = $_GET['delete_id'];
    
    
    if ($crud->delete($id) == false)  {
        header("Location: delete.php?error");	


    }
    else {
    
        header("Location: delete.php?deleted");	
    }
}

?>

<div class="clearfix"></div>

<div class="container">

	<?php
	if(isset($_GET['deleted']))
	{
		?>
        <div class="alert alert-success">
    	<strong>Confirmado!</strong> Registro removido com sucesso ... 
		</div>
        <?php
	}
	else if(isset($_GET['error']))
	{
		?>
        <div class="alert alert-danger">
    	<strong>Esse Registor não pode ser apagado</strong> Existem lançaentos associados a este registro
		</div>
       <?php
    }
	else {
		?>
        <div class="alert alert-danger">
    	<strong>Aten&ccedil;&atilde;o !</strong> Tem certeza que deseja remover o registro ? 
		</div>
        <?php
	}
	?>	
</div>


<div class="clearfix"></div>

<div class="container">
 	
	 <?php
	 if(isset($_GET['delete_id']))
	 {
		 ?>
         <table class='table table-bordered'>
         <tr>
         <th>#</th>
         <th>Descrição</th>
         </tr>
         <?php

         $stmt = $connect->prepare("SELECT * FROM quadra WHERE id=:id");
         $stmt->execute(array(":id"=>$_GET['delete_id']));
         while($row=$stmt->fetch(PDO::FETCH_BOTH))
         {
             ?>
             <tr>
             <td><?php print($row['id']); ?></td>
             <td><?php print($row['descricao']); ?></td>
             </tr>
             <?php
         }
         ?>
         </table>
         <?php
	 }
	 ?>
</div>
<div class="container">
<p>
<?php
if(isset($_GET['delete_id']))
{
	?>
  	<form method="post">
    <input type="hidden" name="id" value="<?php echo $row['id']; ?>" />
    <button class="btn btn-large btn-primary" type="submit" name="btn-del"><i class="glyphicon glyphicon-trash"></i> &nbsp; SIM</button>
    <a href="index.php" class="btn btn-large btn-success"><i class="glyphicon glyphicon-backward"></i> &nbsp; N&Atilde;O</a>
    </form>  
	<?php
}
else
{
	?>
    <a href="index.php" class="btn btn-large btn-success"><i class="glyphicon glyphicon-backward"></i> &nbsp; Volte para In&iacute;cio</a>
    <?php
}
?>
</p>
</div>	