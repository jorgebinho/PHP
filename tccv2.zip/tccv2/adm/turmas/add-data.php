<?php
include_once '../config.php';
//ver o segurança.php 
include_once '../conecta.php';
include_once '../header.php'; 
include_once 'class.crud.php';
$crud = new crud($connect);

if(isset($_POST['btn-save']))
{
	$descricao = $_POST['descricao'];
	$horarios = $_POST['horarios'];
    $categoria_id = $_POST['categoria_id'];
    $quadra_id = $_POST['quadra_id'];
	if($crud->create($horarios,$descricao,$categoria_id,$quadra_id)){
		header("Location: add-data.php?inserted");
	}
	else
	{
		header("Location: add-data.php?failure");
	}
}
?>
<div class="clearfix"></div>

<?php
if(isset($_GET['inserted']))
{
	?>
    <div class="container">
	<div class="alert alert-info">
    <strong>WOW!</strong> Registro inserido com sucesso <a href="index.php">Volte para In&iacute;cio</a>!
	</div>
	</div>
    <?php
}
else if(isset($_GET['failure']))
{
	?>
    <div class="container">
	<div class="alert alert-warning">
    <strong>NÃO DEU!</strong> 
	</div>
	</div>
    <?php
}
?>

<div class="clearfix"></div><br />

<div class="container">

 	
	 <form method='post'>
 
    <table class='table table-bordered'>
        <td>Descrição</td>
        <td><input type='text' name='horarios' class='form-control' required></td>
        </tr>
        <tr>
        <td>Horários</td>
        <td><input type='text' name='descricao' class='form-control' required></td>
        </tr>
        <tr>
            <td>Categoria</td>
            <td>
            <?php 
                $crud->getDropDow("categorias", "descricao", "categoria_id")
            ?>
            </td>
            <tr>
            <td>Quadra</td>
            <td>
            <?php 
                $crud->getDropDow("quadra", "descricao", "quadra_id")
            ?>
            </td>
        <tr>
     
            <td colspan="2">
            <button type="submit" class="btn btn-primary" name="btn-save">
    		<span class="glyphicon glyphicon-plus"></span> Criar novo registro
			</button>  
            <a href="index.php" class="btn btn-large btn-success"><i class="glyphicon glyphicon-backward"></i> &nbsp; Volte para In&iacute;cio</a>
            </td>
        </tr>
 
    </table>
</form>
     
     
</div>