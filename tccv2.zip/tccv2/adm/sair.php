﻿<?php
	session_start();
	unset(
		$_SESSION['login'],
		$_SESSION['senha']);
		
	session_destroy();
	echo "<script> alert ('Sessão de login encerrada!');top.location.href='../index.html';</script>";
?>