<?php
include_once '../config.php';
include_once '../conecta.php';
//ver o segurança.php 
include_once 'class.crud.php';
$crud = new crud($connect);
?>
<?php include_once '../header.php'; ?>

	<div class="clearfix"></div>

	<div class="container">
	<a href="add-data.php" class="btn btn-large btn-info"><i class="glyphicon glyphicon-plus"></i> &nbsp; Adicionar Registro</a>
	</div>

	<div class="clearfix"></div><br />

	<div class="container">
		 <table class='table table-bordered table-responsive'>
		 <tr>
		 <th>#</th>
		 <th>CPF</th>
		 <th>Nome</th>
		 <th>Fone</th>
		 <th>Turma</th>
		 <th>Responsável</th>
		 <th colspan="2" align="center">A&ccedil;&otilde;es</th>
		 </tr>
		 <?php
			$query = "SELECT alunos.id, alunos.cpf, alunos.nome, alunos.fone, turmas.descricao as desct, clientes.nome as nomecli FROM alunos
			INNER JOIN turmas on turmas.id = alunos.turmas_id
			INNER JOIN clientes on clientes.id = alunos.clientes_id";  
			$records_per_page=10;
			$newquery = $crud->paging($query,$records_per_page);
			$crud->dataview($newquery);
		 ?>
		<tr>
			<td colspan="8" align="center">
				<div class="pagination-wrap">
				<?php $crud->paginglink($query,$records_per_page); ?>
				</div>
			</td>
		</tr>
	</table>
	</div>
