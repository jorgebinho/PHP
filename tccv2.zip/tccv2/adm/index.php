<html>
<head>
<meta charset="UTF-8">
</head>
<?php 
include_once 'config.php';
include_once 'header.php';
include_once 'seguranca.php';
?>
<br>
<br>
<br>
<h1><p>
    <CENTER><br><br>
Olá administrador, seja bem vindo a sua área
<br><br>
</CENTER>
</h1>
</p>