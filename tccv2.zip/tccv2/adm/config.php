<?php
define( 'SCRIPT_ROOT', "http://localhost/tccv2/" );
?>