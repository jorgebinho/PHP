<html>
<head>
</head>
<body>
<?php
include_once '../config.php';
include_once '../conecta.php';
//ver o segurança.php 
?>
<?php include_once '../header.php'; ?>
<CENTER>
<iframe src="https://calendar.google.com/calendar/embed?src=batebolafsociety%40gmail.com&ctz=America/Sao_Paulo" style="border: 0" width="800" height="600" frameborder="0" scrolling="no"></iframe>
</CENTER>
</body>
</html>